using System;
using System.IO;

// Classe Menu
class Menu{

// Percorre todas as Linhas e guarda dentro da variável
  public void ExibirMenu(){
  string[] lines = File.ReadAllLines("Menu.txt");
    
      foreach(var line in lines) Console.WriteLine(line);
 }
}