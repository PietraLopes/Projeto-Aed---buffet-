using System;
using System.IO;

class MainClass {
  public static void Main (string[] args) {
      string opcao;
      // Instanciando objetos 
      Cliente cliente = new Cliente();
      Menu menu = new Menu();
      Produto produto = new Produto();
      Pedido pedido = new Pedido();
      Orçamento orçamento = new Orçamento();
      Recibo recibo = new Recibo();
      
      //Inicialização
      Console.WriteLine(" Bem vindo, Selecione a opção desejada: ");
      Console.WriteLine();
      Console.WriteLine("1- Exibir menu\n2- Fazer cadastro\n3- Cadastrados existentes\n4- Orçamento\n5- Fazer pedido\n");
      opcao = Console.ReadLine();

      // Interação com o usuário
      if (opcao == "1")
      {
        //Chamando Método Exibir Menu
        menu.ExibirMenu();        
      } 
      if (opcao == "2")
      {
        // Chamando Método Fazer Cadastro
        cliente.FazerCadastro();
      }
      
      if (opcao == "3")
      { 
        // Chamando Método Cadastrados existentes 
        cliente.Cadastrados();
      }
      if (opcao == "4")
      {
        //Chamando Método Orçamento
        orçamento.Orçamento();
      }

      if (opcao == "5")
      {
        //Chamando Método Fazer Pedido 
        recibo.CriarRecibo();
        pedido.FazerPedido();
        recibo.ImprimirDados();        
      }
      
  }
}
            

      
  
