using System;
using System.IO;

//Classe Cliente 
class Cliente{

  // Atributos da classe cliente
  protected string nome;
  protected string email;
  protected string telefone;
  protected string cpf;
  
  
  //Tornando os atributos publicos para serem utilizados 
  public string Nome{

    get{
      return nome;
    }
    set{
      nome = value;
    }
  }

  public string Email{

    get{
      return email;
    }
    set{
      email = value;
    }
  }

  public string Telefone{

    get{
      return telefone;
    }
    set{
      telefone = value;
    }
  }

  public string Cpf{
    
    get{
      return cpf;
    }
    set{
      cpf = value;
    }
  }
  
  
  public void CadastrosExistentes()
  {
    // Percorre todas as Linhas e guarda dentro da variável
    string[] lines = File.ReadAllLines("CadastrosExistentes.txt");
      foreach(var line in lines) Console.WriteLine(line);
  }
  
  public void FazerCadastro()
  {
    Console.WriteLine("Seu cadastro foi efetuado com sucesso!");
  }
  
}