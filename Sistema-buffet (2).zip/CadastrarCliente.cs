using System;
using System.IO;
using System.Text;

class cadastrarCliente : Cliente{
  private string nome;
  private string cpf;
  private string email;

  public string getNome(){
    return nome;
  }
  public string getCpf(){
    return cpf;
  }
   public string getEmail(){
    return email;
  }

  public string Cliente (string nome, string cpf, string email) {
    return "cadastrarCliente";
  }



  public void setNome (string nomeCliente){
    nome =  nomeCliente;
  }
  public void setCpf (string cpfCliente){
   cpf = cpfCliente;
  }
   public void setEmail (string emailCliente){
   email =  emailCliente;
  }

 
  // método de cadastro cliente 
  public static void cadastrar(){
    Console.WriteLine("Número do cadastro:{0}",numeroCadastro()+1);
    Console.WriteLine( " Por Favor, digite as seguintes informações para criar seu cadastro: Nome, cpf e email");
    string dados = Console.ReadLine();
    
    FileStream arq = new FileStream("Cliente.text",FileMode.Append,FileAccess.Write);
    StreamWriter informaçoesbasicas= new StreamWriter(arq, Encoding.UTF7);    
    string infobasic = dados;
    informaçoesbasicas.WriteLine(infobasic);
    informaçoesbasicas.Close();
    arq.Close(); 
    Console.WriteLine ("Cadastro realizado com sucesso!");
    System.Threading.Thread.Sleep(TimeSpan.FromSeconds(3)); 

  }
   
  // metódo do número de cadastro do cliente 
  public static int numeroCadastro(){
    int i = 0;
    FileStream  leiturArqCliente= new FileStream("Cliente.text",FileMode.Open,FileAccess.Read);
    StreamReader infoBasic = new StreamReader(leiturArqCliente,Encoding.UTF8);
 
    while(!infoBasic.EndOfStream){
      infoBasic.ReadLine();
      i++;
    } 
    infoBasic.Close();
    leiturArqCliente.Close();
    return i;
  } 
  public static Cliente retornaCliente(int numeroCadastro){
    int cont = 0;
    string cadastro = null;
    FileStream  leiturArqCliente= new FileStream("Cliente.text",FileMode.Open,FileAccess.Read);
    StreamReader infoBasic =new StreamReader(leiturArqCliente,Encoding.UTF8);   
    while(!infoBasic.EndOfStream){
      cont++;
      string linha = infoBasic.ReadLine();
      if( numeroCadastro == cont){
        cadastro = linha;  
       
      }  
    } 
    infoBasic.Close();
    leiturArqCliente.Close();
    
    string[] linhainformaçoes = cadastro.Split('/');
    string  nome = linhainformaçoes[0];
    string cpf = linhainformaçoes[1];
    string email = linhainformaçoes[2];
    Cliente cliente = new Cliente(nome,cpf,email);
    
    return cliente;
  }
  

}